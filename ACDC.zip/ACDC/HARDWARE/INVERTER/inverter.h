#ifndef __INVERTER_H
#define __INVERTER_H
#include "stm32f10x.h"


void inverter_spwm(void);


#endif


