#ifndef __ADC_H
#define	__ADC_H


#include "stm32f10x.h"

void Init_adc(void);

#endif /* __ADC_H */

