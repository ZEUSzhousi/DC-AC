#ifndef __MAIN_H
#define __MAIN_H
#include "sys.h"
extern float inverter_duty;
extern u16 AC_V1_vref;
//extern float AC_V1_vref;
extern float AC_V1_ratio;
extern u8 jisuan_status;
extern u8 start_status;
extern u8 protect_status;
#endif
